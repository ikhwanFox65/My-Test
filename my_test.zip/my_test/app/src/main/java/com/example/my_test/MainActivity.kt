package com.example.my_test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*



class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var txt1 = findViewById(R.id.txt1) as EditText
        var txt2 = findViewById(R.id.txt2) as EditText
        var b1 = findViewById(R.id.b1) as Button
        var b2 = findViewById(R.id.b2) as Button


        b1.setOnClickListener {
            val user_name = txt1.text;
            val password = txt2.text;
            Toast.makeText(this,user_name, Toast.LENGTH_LONG)
         }

        b2.setOnClickListener {
            txt1.setText("")
            txt2.setText("")
        }
    }
}